from .record import bp

record_blueprints = [bp]
