from .user import bp

"""
Add your user blueprints here
"""
user_blueprints = [bp]
