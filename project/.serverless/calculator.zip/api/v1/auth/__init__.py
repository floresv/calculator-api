from .core import bp

auth_blueprints = [bp]
