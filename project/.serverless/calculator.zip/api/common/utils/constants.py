class Constants:
    """
    Useful constants
    """

    class HttpHeaders:
        AUTHORIZATION = "Authorization"
